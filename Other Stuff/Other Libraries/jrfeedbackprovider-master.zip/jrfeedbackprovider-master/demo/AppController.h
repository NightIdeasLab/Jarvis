//
//  AppController.h
//  JRFeedbackProvider
//
//  Created by wolf on 4/10/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppController : NSObject {

}

- (IBAction)showFeedback:(id)sender;

@end
